function getLargestNum(num1, num2, num3) {
    // using default function of javascript math max
    return Math.max(num1, num2, num3);
}

//test
console.log(getLargestNum (1,0,1));
console.log(getLargestNum (0,-10,-20));
console.log(getLargestNum (1000,510,440));
