
var values = [1, 60, 34, 3, 20, 5];

function filterLessThanTwenty(arr) {
  return arr.filter(value => value >= 20);
}

console.log(filterLessThanTwenty(values));
