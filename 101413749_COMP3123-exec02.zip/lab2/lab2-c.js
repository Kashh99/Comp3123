// Ex 2
function capitalize(word) {
    return word.charAt(0).toUpperCase() + word.slice(1);
  }
  
  // Ex 3
  const colors = ['red', 'green', 'blue'];
  const capitalizedColors = colors.map(color => capitalize(color));
  
  console.log(capitalizedColors);
