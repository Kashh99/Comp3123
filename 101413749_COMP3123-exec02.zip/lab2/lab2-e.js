var array = [1, 2, 3, 4];

function calculateSum(arr) {
  return arr.reduce((sum, value) => sum + value, 0);
}

function calculateProduct(arr) {
  return arr.reduce((product, value) => product * value, 1);
}

console.log(calculateSum(array)); 
console.log(calculateProduct(array)); 
